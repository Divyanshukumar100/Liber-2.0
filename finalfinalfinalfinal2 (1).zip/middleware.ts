import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { createMiddlewareClient } from "@supabase/auth-helpers-nextjs"

// Routes that require authentication
const protectedRoutes = ["/app", "/profile", "/messages", "/notifications", "/explore"]

// Routes that should redirect to /app if the user is already authenticated
const authRoutes = ["/sign-in", "/sign-up", "/forgot-password", "/reset-password"]

export async function middleware(request: NextRequest) {
  const response = NextResponse.next()
  const supabase = createMiddlewareClient({ req: request, res: response })

  // Check if the user is authenticated
  const {
    data: { session },
  } = await supabase.auth.getSession()
  const isAuthenticated = !!session
  const path = request.nextUrl.pathname

  // Redirect unauthenticated users from protected routes to sign-in
  if (!isAuthenticated && protectedRoutes.some((route) => path.startsWith(route))) {
    const redirectUrl = new URL("/sign-in", request.url)
    redirectUrl.searchParams.set("redirect", path)
    return NextResponse.redirect(redirectUrl)
  }

  // Redirect authenticated users from auth routes to app
  if (isAuthenticated && authRoutes.some((route) => path.startsWith(route))) {
    return NextResponse.redirect(new URL("/app", request.url))
  }

  return response
}

export const config = {
  matcher: [
    // Match all routes except static files, api routes, and _next
    "/((?!_next/static|_next/image|favicon.ico|api/|auth/).*)",
  ],
}

