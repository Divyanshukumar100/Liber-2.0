import { createServerClient } from "@/lib/supabase"
import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url)
  const code = searchParams.get("code")

  // If code is not present, redirect to sign-in page
  if (!code) {
    return NextResponse.redirect(`${origin}/sign-in`)
  }

  try {
    const supabase = createServerClient()

    // Exchange the code for a session
    const { data, error } = await supabase.auth.exchangeCodeForSession(code)

    if (error) {
      console.error("Error exchanging code for session:", error)
      return NextResponse.redirect(`${origin}/sign-in?error=Authentication failed`)
    }

    // Check if user profile exists, create if not
    if (data.user) {
      try {
        const { data: userData, error: userError } = await supabase
          .from("users")
          .select("id")
          .eq("id", data.user.id)
          .single()

        if (userError && userError.code === "PGRST116") {
          // User not found, create profile
          // For GitHub users, extract username from user metadata
          const githubUsername =
            data.user.user_metadata.user_name ||
            data.user.user_metadata.preferred_username ||
            `user_${data.user.id.slice(0, 6)}`

          // Generate a random placeholder address for users without wallets
          const placeholderAddress = `0x${Array.from({ length: 40 }, () =>
            Math.floor(Math.random() * 16).toString(16),
          ).join("")}`

          const { error: insertError } = await supabase.from("users").insert({
            id: data.user.id,
            address: placeholderAddress,
            username: githubUsername,
            avatar_url: data.user.user_metadata.avatar_url || "/placeholder.svg?height=150&width=150",
            banner_url: "/placeholder.svg?height=300&width=1200",
            bio: "Web3 enthusiast and Liber user",
          })

          if (insertError) {
            console.error("Error creating user profile:", insertError)
          }
        }
      } catch (profileError) {
        console.error("Error handling user profile:", profileError)
        // Continue even if profile creation fails
      }
    }

    // Redirect to the app
    return NextResponse.redirect(`${origin}/app`)
  } catch (error) {
    console.error("Error in auth callback:", error)
    return NextResponse.redirect(`${origin}/sign-in?error=Something went wrong`)
  }
}

