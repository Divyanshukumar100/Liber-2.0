import { NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"

export async function GET() {
  try {
    const supabase = createServerClient()

    // Create buckets if they don't exist
    const buckets = ["post-images", "avatars", "banners"]

    for (const bucket of buckets) {
      const { data, error } = await supabase.storage.createBucket(bucket, {
        public: true,
        fileSizeLimit: 10485760, // 10MB
      })

      if (error && !error.message.includes("already exists")) {
        return NextResponse.json({ error: error.message }, { status: 500 })
      }
    }

    return NextResponse.json({ success: true, message: "Buckets created successfully" })
  } catch (error: any) {
    console.error("Error creating buckets:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

