"use client"

import { createContext, useContext, useState, type ReactNode, useEffect } from "react"
import { useWeb3 } from "@/components/web3-provider"
import { useToast } from "@/components/ui/use-toast"
import { getBrowserClient } from "@/lib/supabase"

// Define the comment type
export interface Comment {
  id: string
  postId: string
  content: string
  author: {
    address: string
    username: string
    avatar: string
  }
  createdAt: string
}

// Define the post type
export interface Post {
  id: string
  title: string
  content: string
  author: {
    address: string
    username: string
    avatar: string
  }
  createdAt: string
  upvotes: number
  downvotes: number
  commentCount: number
  shareCount: number
  tokenId: string
  isMinted: boolean
  imageUrl?: string
  txHash?: string
}

interface PostContextType {
  posts: Post[]
  addPost: (
    post: Omit<Post, "id" | "createdAt" | "upvotes" | "downvotes" | "commentCount" | "shareCount">,
  ) => Promise<Post>
  updatePost: (postId: string, updates: Partial<Post>) => Promise<void>
  userPosts: Post[]
  isLoading: boolean
  comments: Comment[]
  addComment: (comment: Omit<Comment, "id" | "createdAt">) => Promise<Comment>
  getPostComments: (postId: string) => Comment[]
  incrementShareCount: (postId: string) => Promise<void>
  mintPost: (postId: string) => Promise<void>
  upvotePost: (postId: string) => Promise<void>
  downvotePost: (postId: string) => Promise<void>
  hasUserVoted: (postId: string) => { upvoted: boolean; downvoted: boolean }
}

const PostContext = createContext<PostContextType | undefined>(undefined)

export function PostProvider({ children }: { children: ReactNode }) {
  const [posts, setPosts] = useState<Post[]>([])
  const [comments, setComments] = useState<Comment[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [userVotes, setUserVotes] = useState<Record<string, { upvoted: boolean; downvoted: boolean }>>({})
  const { account, mintNFT, isCorrectNetwork } = useWeb3()
  const { toast } = useToast()
  const supabase = getBrowserClient()

  // Load posts from Supabase
  useEffect(() => {
    const fetchPosts = async () => {
      try {
        setIsLoading(true)

        // Fetch posts with author information
        const { data: postsData, error: postsError } = await supabase
          .from("posts")
          .select(`
            id,
            title,
            content,
            image_url,
            token_id,
            tx_hash,
            is_minted,
            created_at,
            users (
              id,
              address,
              username,
              avatar_url
            )
          `)
          .order("created_at", { ascending: false })

        if (postsError) {
          console.error("Error fetching posts:", postsError)
          return
        }

        // Fetch upvotes/downvotes counts for each post
        const postsWithCounts = await Promise.all(
          postsData.map(async (post) => {
            // Get upvotes count
            const { count: upvotes } = await supabase
              .from("likes")
              .select("id", { count: "exact", head: true })
              .eq("post_id", post.id)
              .eq("is_upvote", true)

            // Get downvotes count
            const { count: downvotes } = await supabase
              .from("likes")
              .select("id", { count: "exact", head: true })
              .eq("post_id", post.id)
              .eq("is_upvote", false)

            // Get comments count
            const { count: commentCount } = await supabase
              .from("comments")
              .select("id", { count: "exact", head: true })
              .eq("post_id", post.id)

            // Get shares count
            const { count: shareCount } = await supabase
              .from("shares")
              .select("id", { count: "exact", head: true })
              .eq("post_id", post.id)

            // Check if current user has voted on this post
            if (account) {
              const { data: userData } = await supabase.from("users").select("id").eq("address", account).single()

              if (userData) {
                const { data: userLike } = await supabase
                  .from("likes")
                  .select("is_upvote")
                  .eq("post_id", post.id)
                  .eq("user_id", userData.id)
                  .single()

                if (userLike) {
                  setUserVotes((prev) => ({
                    ...prev,
                    [post.id]: { upvoted: userLike.is_upvote, downvoted: !userLike.is_upvote },
                  }))
                }
              }
            }

            return {
              id: post.id,
              title: post.title,
              content: post.content,
              author: {
                address: post.users.address,
                username: post.users.username,
                avatar: post.users.avatar_url || "/placeholder.svg?height=50&width=50",
              },
              createdAt: post.created_at,
              upvotes: upvotes || 0,
              downvotes: downvotes || 0,
              commentCount: commentCount || 0,
              shareCount: shareCount || 0,
              tokenId: post.token_id || "",
              isMinted: post.is_minted || false,
              imageUrl: post.image_url,
              txHash: post.tx_hash,
            }
          }),
        )

        setPosts(postsWithCounts)
      } catch (error) {
        console.error("Error in fetchPosts:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchPosts()

    // Set up real-time subscription for posts
    const postsSubscription = supabase
      .channel("public:posts")
      .on("postgres_changes", { event: "*", schema: "public", table: "posts" }, () => {
        fetchPosts()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(postsSubscription)
    }
  }, [account, supabase])

  // Load comments from Supabase
  useEffect(() => {
    const fetchComments = async () => {
      try {
        const { data: commentsData, error: commentsError } = await supabase
          .from("comments")
          .select(`
            id,
            content,
            post_id,
            created_at,
            users (
              id,
              address,
              username,
              avatar_url
            )
          `)
          .order("created_at", { ascending: false })

        if (commentsError) {
          console.error("Error fetching comments:", commentsError)
          return
        }

        const formattedComments = commentsData.map((comment) => ({
          id: comment.id,
          postId: comment.post_id,
          content: comment.content,
          author: {
            address: comment.users.address,
            username: comment.users.username,
            avatar: comment.users.avatar_url || "/placeholder.svg?height=50&width=50",
          },
          createdAt: comment.created_at,
        }))

        setComments(formattedComments)
      } catch (error) {
        console.error("Error in fetchComments:", error)
      }
    }

    fetchComments()

    // Set up real-time subscription for comments
    const commentsSubscription = supabase
      .channel("public:comments")
      .on("postgres_changes", { event: "*", schema: "public", table: "comments" }, () => {
        fetchComments()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(commentsSubscription)
    }
  }, [supabase])

  // Ensure user exists in the database
  useEffect(() => {
    const ensureUserExists = async () => {
      if (!account) return

      try {
        // Check if user exists
        const { data: existingUser } = await supabase
          .from("users")
          .select("id, username, avatar_url")
          .eq("address", account)
          .single()

        if (!existingUser) {
          // Create new user
          const { data: newUser, error } = await supabase
            .from("users")
            .insert({
              address: account,
              username: `user_${account.slice(2, 8)}`,
              avatar_url: "/placeholder.svg?height=50&width=50",
            })
            .select()
            .single()

          if (error) {
            console.error("Error creating user:", error)
          }
        }
      } catch (error) {
        console.error("Error in ensureUserExists:", error)
      }
    }

    ensureUserExists()
  }, [account, supabase])

  const addPost = async (
    postData: Omit<Post, "id" | "createdAt" | "upvotes" | "downvotes" | "commentCount" | "shareCount">,
  ) => {
    if (!account) {
      throw new Error("Wallet not connected")
    }

    try {
      // Get user ID
      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("id")
        .eq("address", account)
        .single()

      if (userError) {
        throw new Error("User not found")
      }

      // Insert post
      const { data: newPost, error: postError } = await supabase
        .from("posts")
        .insert({
          title: postData.title,
          content: postData.content,
          image_url: postData.imageUrl,
          author_id: userData.id,
          token_id: postData.tokenId,
          is_minted: postData.isMinted,
        })
        .select(`
          id,
          title,
          content,
          image_url,
          token_id,
          tx_hash,
          is_minted,
          created_at,
          users (
            id,
            address,
            username,
            avatar_url
          )
        `)
        .single()

      if (postError) {
        throw new Error(postError.message)
      }

      const createdPost: Post = {
        id: newPost.id,
        title: newPost.title,
        content: newPost.content,
        author: {
          address: newPost.users.address,
          username: newPost.users.username,
          avatar: newPost.users.avatar_url || "/placeholder.svg?height=50&width=50",
        },
        createdAt: newPost.created_at,
        upvotes: 0,
        downvotes: 0,
        commentCount: 0,
        shareCount: 0,
        tokenId: newPost.token_id || "",
        isMinted: newPost.is_minted || false,
        imageUrl: newPost.image_url,
        txHash: newPost.tx_hash,
      }

      setPosts((prevPosts) => [createdPost, ...prevPosts])
      return createdPost
    } catch (error: any) {
      console.error("Error adding post:", error)
      throw error
    }
  }

  const updatePost = async (postId: string, updates: Partial<Post>) => {
    try {
      // Convert from frontend model to database model
      const dbUpdates: any = {}

      if (updates.title !== undefined) dbUpdates.title = updates.title
      if (updates.content !== undefined) dbUpdates.content = updates.content
      if (updates.imageUrl !== undefined) dbUpdates.image_url = updates.imageUrl
      if (updates.tokenId !== undefined) dbUpdates.token_id = updates.tokenId
      if (updates.isMinted !== undefined) dbUpdates.is_minted = updates.isMinted
      if (updates.txHash !== undefined) dbUpdates.tx_hash = updates.txHash

      const { error } = await supabase.from("posts").update(dbUpdates).eq("id", postId)

      if (error) {
        throw new Error(error.message)
      }

      // Update local state
      setPosts((prevPosts) => prevPosts.map((post) => (post.id === postId ? { ...post, ...updates } : post)))
    } catch (error: any) {
      console.error("Error updating post:", error)
      throw error
    }
  }

  const addComment = async (commentData: Omit<Comment, "id" | "createdAt">) => {
    if (!account) {
      throw new Error("Wallet not connected")
    }

    try {
      // Get user ID
      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("id")
        .eq("address", account)
        .single()

      if (userError) {
        throw new Error("User not found")
      }

      // Insert comment
      const { data: newComment, error: commentError } = await supabase
        .from("comments")
        .insert({
          content: commentData.content,
          post_id: commentData.postId,
          author_id: userData.id,
        })
        .select(`
          id,
          content,
          post_id,
          created_at,
          users (
            id,
            address,
            username,
            avatar_url
          )
        `)
        .single()

      if (commentError) {
        throw new Error(commentError.message)
      }

      const createdComment: Comment = {
        id: newComment.id,
        postId: newComment.post_id,
        content: newComment.content,
        author: {
          address: newComment.users.address,
          username: newComment.users.username,
          avatar: newComment.users.avatar_url || "/placeholder.svg?height=50&width=50",
        },
        createdAt: newComment.created_at,
      }

      setComments((prevComments) => [createdComment, ...prevComments])

      // Update comment count on the post
      const postToUpdate = posts.find((p) => p.id === commentData.postId)
      if (postToUpdate) {
        const updatedPost = {
          ...postToUpdate,
          commentCount: postToUpdate.commentCount + 1,
        }

        setPosts((prevPosts) => prevPosts.map((post) => (post.id === commentData.postId ? updatedPost : post)))
      }

      return createdComment
    } catch (error: any) {
      console.error("Error adding comment:", error)
      throw error
    }
  }

  const getPostComments = (postId: string) => {
    return comments
      .filter((comment) => comment.postId === postId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
  }

  const incrementShareCount = async (postId: string) => {
    if (!account) {
      throw new Error("Wallet not connected")
    }

    try {
      // Get user ID
      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("id")
        .eq("address", account)
        .single()

      if (userError) {
        throw new Error("User not found")
      }

      // Record share
      const { error: shareError } = await supabase
        .from("shares")
        .insert({
          post_id: postId,
          user_id: userData.id,
        })
        .select()
        .single()

      if (shareError && !shareError.message.includes("unique constraint")) {
        throw new Error(shareError.message)
      }

      // Update local state
      const postToUpdate = posts.find((p) => p.id === postId)
      if (postToUpdate) {
        const updatedPost = {
          ...postToUpdate,
          shareCount: postToUpdate.shareCount + 1,
        }

        setPosts((prevPosts) => prevPosts.map((post) => (post.id === postId ? updatedPost : post)))
      }
    } catch (error: any) {
      console.error("Error incrementing share count:", error)
      throw error
    }
  }

  const upvotePost = async (postId: string) => {
    if (!account) {
      throw new Error("Wallet not connected")
    }

    try {
      // Get user ID
      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("id")
        .eq("address", account)
        .single()

      if (userError) {
        throw new Error("User not found")
      }

      const currentVote = userVotes[postId]

      if (currentVote?.upvoted) {
        // Remove upvote
        const { error } = await supabase.from("likes").delete().eq("post_id", postId).eq("user_id", userData.id)

        if (error) throw new Error(error.message)

        // Update local state
        setUserVotes((prev) => ({
          ...prev,
          [postId]: { upvoted: false, downvoted: false },
        }))

        const postToUpdate = posts.find((p) => p.id === postId)
        if (postToUpdate) {
          setPosts((prevPosts) =>
            prevPosts.map((post) => (post.id === postId ? { ...post, upvotes: post.upvotes - 1 } : post)),
          )
        }
      } else {
        // Add upvote (or change from downvote to upvote)
        if (currentVote?.downvoted) {
          // Change from downvote to upvote
          const { error } = await supabase
            .from("likes")
            .update({ is_upvote: true })
            .eq("post_id", postId)
            .eq("user_id", userData.id)

          if (error) throw new Error(error.message)

          // Update local state
          setUserVotes((prev) => ({
            ...prev,
            [postId]: { upvoted: true, downvoted: false },
          }))

          const postToUpdate = posts.find((p) => p.id === postId)
          if (postToUpdate) {
            setPosts((prevPosts) =>
              prevPosts.map((post) =>
                post.id === postId
                  ? {
                      ...post,
                      upvotes: post.upvotes + 1,
                      downvotes: post.downvotes - 1,
                    }
                  : post,
              ),
            )
          }
        } else {
          // New upvote
          const { error } = await supabase.from("likes").insert({
            post_id: postId,
            user_id: userData.id,
            is_upvote: true,
          })

          if (error) throw new Error(error.message)

          // Update local state
          setUserVotes((prev) => ({
            ...prev,
            [postId]: { upvoted: true, downvoted: false },
          }))

          const postToUpdate = posts.find((p) => p.id === postId)
          if (postToUpdate) {
            setPosts((prevPosts) =>
              prevPosts.map((post) => (post.id === postId ? { ...post, upvotes: post.upvotes + 1 } : post)),
            )
          }
        }
      }
    } catch (error: any) {
      console.error("Error upvoting post:", error)
      throw error
    }
  }

  const downvotePost = async (postId: string) => {
    if (!account) {
      throw new Error("Wallet not connected")
    }

    try {
      // Get user ID
      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("id")
        .eq("address", account)
        .single()

      if (userError) {
        throw new Error("User not found")
      }

      const currentVote = userVotes[postId]

      if (currentVote?.downvoted) {
        // Remove downvote
        const { error } = await supabase.from("likes").delete().eq("post_id", postId).eq("user_id", userData.id)

        if (error) throw new Error(error.message)

        // Update local state
        setUserVotes((prev) => ({
          ...prev,
          [postId]: { upvoted: false, downvoted: false },
        }))

        const postToUpdate = posts.find((p) => p.id === postId)
        if (postToUpdate) {
          setPosts((prevPosts) =>
            prevPosts.map((post) => (post.id === postId ? { ...post, downvotes: post.downvotes - 1 } : post)),
          )
        }
      } else {
        // Add downvote (or change from upvote to downvote)
        if (currentVote?.upvoted) {
          // Change from upvote to downvote
          const { error } = await supabase
            .from("likes")
            .update({ is_upvote: false })
            .eq("post_id", postId)
            .eq("user_id", userData.id)

          if (error) throw new Error(error.message)

          // Update local state
          setUserVotes((prev) => ({
            ...prev,
            [postId]: { upvoted: false, downvoted: true },
          }))

          const postToUpdate = posts.find((p) => p.id === postId)
          if (postToUpdate) {
            setPosts((prevPosts) =>
              prevPosts.map((post) =>
                post.id === postId
                  ? {
                      ...post,
                      upvotes: post.upvotes - 1,
                      downvotes: post.downvotes + 1,
                    }
                  : post,
              ),
            )
          }
        } else {
          // New downvote
          const { error } = await supabase.from("likes").insert({
            post_id: postId,
            user_id: userData.id,
            is_upvote: false,
          })

          if (error) throw new Error(error.message)

          // Update local state
          setUserVotes((prev) => ({
            ...prev,
            [postId]: { upvoted: false, downvoted: true },
          }))

          const postToUpdate = posts.find((p) => p.id === postId)
          if (postToUpdate) {
            setPosts((prevPosts) =>
              prevPosts.map((post) => (post.id === postId ? { ...post, downvotes: post.downvotes + 1 } : post)),
            )
          }
        }
      }
    } catch (error: any) {
      console.error("Error downvoting post:", error)
      throw error
    }
  }

  const hasUserVoted = (postId: string) => {
    return userVotes[postId] || { upvoted: false, downvoted: false }
  }

  const mintPost = async (postId: string): Promise<void> => {
    if (!account) {
      throw new Error("Wallet not connected")
    }

    if (!isCorrectNetwork) {
      throw new Error("Please switch to Sepolia network to mint NFTs")
    }

    const post = posts.find((p) => p.id === postId)
    if (!post) {
      throw new Error("Post not found")
    }

    // Create metadata for the NFT
    const metadata = {
      name: post.title,
      description: post.content,
      image: post.imageUrl || "https://via.placeholder.com/500",
      attributes: [
        {
          trait_type: "Author",
          value: post.author.username,
        },
        {
          trait_type: "Created",
          value: new Date(post.createdAt).toISOString(),
        },
      ],
    }

    // In a real app, we would upload this metadata to IPFS
    // For this demo, we'll use a mock URI
    const tokenURI = `ipfs://QmExample/${postId}`

    try {
      // Call the mintNFT function from the Web3Provider
      const txHash = await mintNFT(tokenURI)

      // Update the post with the transaction hash and mark it as minted
      await updatePost(postId, {
        isMinted: true,
        txHash,
      })

      toast({
        title: "NFT Minted Successfully",
        description: "Your post has been minted as an NFT on the Sepolia network",
      })
    } catch (error: any) {
      toast({
        title: "Minting failed",
        description: error.message || "Failed to mint NFT",
        variant: "destructive",
      })
      throw error
    }
  }

  // Filter posts by the current user's address
  const userPosts = posts.filter(
    (post) => account && post.author.address && post.author.address.toLowerCase() === account.toLowerCase(),
  )

  return (
    <PostContext.Provider
      value={{
        posts,
        addPost,
        updatePost,
        userPosts,
        isLoading,
        comments,
        addComment,
        getPostComments,
        incrementShareCount,
        mintPost,
        upvotePost,
        downvotePost,
        hasUserVoted,
      }}
    >
      {children}
    </PostContext.Provider>
  )
}

export function usePosts() {
  const context = useContext(PostContext)
  if (context === undefined) {
    throw new Error("usePosts must be used within a PostProvider")
  }
  return context
}

